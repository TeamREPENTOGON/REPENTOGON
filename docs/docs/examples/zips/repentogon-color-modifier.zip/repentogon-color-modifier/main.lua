local mod = RegisterMod("Repentogon Color Modifiers", 1)
local game = Game()

local RED_LENGTH = 3

-- Make our red color modifier.
local redModifier = ColorModifier(1, 0, 0, 0.33, 0, 2)

-- Add a red color modifier when the player is hurt.
function mod:OnPlayerHurt()
    -- Set the red effect. "lerp" stands for linear interpolation, and means it'll "fade" to our color modifier from the current one.
    game:SetColorModifier(redModifier, true, 0.3)

    -- Fade back to normal after RED_LENGTH frames.
    Isaac.CreateTimer(function ()
        -- Set's the color modifier back to what was specified in "fxparams.xml".
        game:GetRoom():UpdateColorModifier(true, true, 0.05)
    end, RED_LENGTH, 1, false)
end

mod:AddCallback(ModCallbacks.MC_ENTITY_TAKE_DMG, mod.OnPlayerHurt, EntityType.ENTITY_PLAYER)