local mod = RegisterMod("Repentogon Devil Chance", 1)
local game = Game()

-- The item "Dark Spellcasting Tome" will set the devil deal chance to
-- a random percentage every frame while in an uncleared boss room.
local ITEM_ID = Isaac.GetItemIdByName("Dark Spellcasting Tome")

-- Store the random chance that will be set when the boss room is cleared.
local modifiedChance = 0

-- There's four callbacks for devil chance that are applied at different times.
-- The one we're using is MC_PRE_DEVIL_APPLY_SPECIAL_ITEMS.
-- This is where the game applies chances that bypass the stage penalty, such as Goat Head and Eucharist.
-- There's also MC_PRE_DEVIL_APPLY_ITEMS, which is where most items apply their modified chance.

-- If in a boss room and it isn't cleared, set the chance to something random.
function mod:RandomizeDevilChance()
    -- Check if we should actually do the item's effects.
    -- We need the RNG for later so we'll check if the following variable is nil.
    local firstPlayer = PlayerManager.FirstCollectibleOwner(ITEM_ID)
    if firstPlayer then
        local room = game:GetRoom()

        -- Only do this in a boss room.
        if room:GetType() == RoomType.ROOM_BOSS then
            -- Check if in a boss room and if isn't clear, and randomize if so.
            if not room:IsClear() then
                local rng = firstPlayer:GetCollectibleRNG(ITEM_ID)

                -- Random chance between 0% and 100%.
                modifiedChance = rng:RandomFloat()
            end

            return modifiedChance
        end
    end
end

mod:AddCallback(ModCallbacks.MC_PRE_DEVIL_APPLY_SPECIAL_ITEMS, mod.RandomizeDevilChance)